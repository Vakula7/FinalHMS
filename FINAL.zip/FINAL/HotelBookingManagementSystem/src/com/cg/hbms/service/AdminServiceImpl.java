package com.cg.hbms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbms.dao.IAdminDao;
import com.cg.hbms.entities.Bookings;
import com.cg.hbms.entities.Hotels;
import com.cg.hbms.entities.Rooms;
import com.cg.hbms.exception.HBMSException;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {

	@Autowired
	IAdminDao dao;
	
	public IAdminDao getDao() {
		return dao;
	}

	public void setDao(IAdminDao dao) {
		this.dao = dao;
	}

	@Override
	public int persistHotel(Hotels hotel) throws HBMSException {
		
		return dao.persistHotel(hotel);
	}

	@Override
	public List<Hotels> showHotelList() throws HBMSException {
		// TODO Auto-generated method stub
		return dao.showHotelList();
	}

	@Override
	public Hotels updateHotel(Hotels hotel) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.updateHotel(hotel);
	}


	@Override
	public int deleteHotel(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.deleteHotel(hotelId);
	}

	@Override
	public Hotels getHotelById(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.getHotelById(hotelId);
	}

	@Override
	public List<Rooms> showRoomsList(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.showRoomsList(hotelId);
	}

	@Override
	public int persistRoom(Rooms room) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.persistRoom(room);
	}



	/*@Override
	public List<Rooms> getRoomDetailsById(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.ge;
	}
*/
	/*@Override
	public Hotels getHotelByID(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.getHotelById(hotelId);
	}
*/
	
	
}
