package com.cg.hbms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbms.dao.UserDao;
import com.cg.hbms.entities.Bookings;
import com.cg.hbms.entities.Hotels;
import com.cg.hbms.entities.Rooms;
import com.cg.hbms.entities.Users;
import com.cg.hbms.exception.HBMSException;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao dao;
	
	
	public UserDao getDao() {
		return dao;
	}


	public void setDao(UserDao dao) {
		this.dao = dao;
	}


	@Override
	public Users validateUser(Users user) throws HBMSException {
		// TODO Auto-generated method stub
		
		return dao.validateUser(user);
	}


	@Override
	public void registerUser(Users user) throws HBMSException {
		
		user.setRole("customer");
		dao.registerUser(user);
		
	}


	@Override
	public List<Hotels> getHotelByPlace(String place) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.getHotelByPlace(place);
	}


	@Override
	public Hotels getHotelByID(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.getHotelByID(hotelId);
	}


	@Override
	public List<Rooms> getRoomDetailsById(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.getRoomDetailsById(hotelId);
	}


	@Override
	public double getFareByRoomId(int roomId) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.getFareByRoomId(roomId);
	}


	@Override
	public int persistBookingDetails(Bookings bookingDetails)
			throws HBMSException {
		// TODO Auto-generated method stub
		return dao.persistBookingDetails(bookingDetails);
	}


	@Override
	public void changeAvailability(int roomId) throws HBMSException {
		// TODO Auto-generated method stub
		dao.changeAvailability(roomId);
	}

}
