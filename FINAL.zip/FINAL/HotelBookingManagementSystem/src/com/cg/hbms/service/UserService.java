package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.entities.Bookings;
import com.cg.hbms.entities.Hotels;
import com.cg.hbms.entities.Rooms;
import com.cg.hbms.entities.Users;
import com.cg.hbms.exception.HBMSException;

public interface UserService {
	public Users validateUser(Users user) throws HBMSException;
	
	public void registerUser(Users user) throws HBMSException;
	
	public List<Hotels> getHotelByPlace(String place) throws  HBMSException;
	
	public Hotels getHotelByID(int hotelId) throws HBMSException;
	
	public List<Rooms> getRoomDetailsById(int hotelId) throws HBMSException;
	
	public double getFareByRoomId(int roomId) throws HBMSException;
	
	public int persistBookingDetails(Bookings bookingDetails) throws HBMSException;
	public void changeAvailability(int roomId) throws HBMSException;
}
