package com.cg.hbms.exception;

public class HBMSException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public HBMSException(String message)
	{
		super(message);
	}
}
