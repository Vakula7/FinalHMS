package com.cg.hbms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hbms.entities.Bookings;
import com.cg.hbms.entities.Hotels;
import com.cg.hbms.entities.Rooms;
import com.cg.hbms.entities.Users;
import com.cg.hbms.exception.HBMSException;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Users validateUser(Users user) throws HBMSException {
		
	
		try {
			TypedQuery<Users> tQuery=entityManager.createQuery("FROM Users WHERE  userName=? AND password=?", Users.class);
			tQuery.setParameter(1, user.getUserName());
			tQuery.setParameter(2, user.getPassword());
			
			user=tQuery.getSingleResult();
			
		
		} catch (Exception e) {
			
			throw new HBMSException(e.getMessage());
			
		}
		return user;
		
	}

	@Override
	public void registerUser(Users user) throws HBMSException {
	
		Users userData=null;
		userData=entityManager.find(Users.class, user.getUserName());
		if(userData==null)
		{
			entityManager.persist(user);
			entityManager.flush();
		}
		else
		{
			throw new HBMSException("SignUp failed User name already exists");
		}
	}

	@Override
	public List<Hotels> getHotelByPlace(String place) throws HBMSException {
		// TODO Auto-generated method stub
	
		List<Hotels> hotelList=null;
		TypedQuery<Hotels> query=entityManager.createQuery("FROM Hotels WHERE city=?", Hotels.class);
		query.setParameter(1, place);
		hotelList=query.getResultList();
		return hotelList;
		
	}

	@Override
	public Hotels getHotelByID(int hotelId) throws HBMSException {
		
		Hotels hotel=null;
		hotel=entityManager.find(Hotels.class, hotelId);
		return hotel;
	}

	@Override
	public List<Rooms> getRoomDetailsById(int hotelId) throws HBMSException {
		List<Rooms> roomList=null;
		
		TypedQuery<Rooms> tQuery=entityManager.createQuery("FROM Rooms WHERE hotelId=:id AND availability='yes'", Rooms.class);
		tQuery.setParameter("id", hotelId);
		roomList=tQuery.getResultList();
		
		return roomList;
	}

	@Override
	public double getFareByRoomId(int roomId) throws HBMSException {
		double fare=0;
		
		Rooms roomDetails=null;
		TypedQuery<Rooms> tQuery=entityManager.createQuery("FROM Rooms WHERE roomId=:id", Rooms.class);
		
		tQuery.setParameter("id", roomId);
		
		roomDetails=tQuery.getSingleResult();
		
		fare=roomDetails.getRatePerNight();
		
		return fare;
	}

	@Override
	public int persistBookingDetails(Bookings bookingDetails)
			throws HBMSException {
	int bookingId=0;
	
	entityManager.persist(bookingDetails);
	
	bookingId=bookingDetails.getBookingId();
	
		return bookingId ;
	}

	@Override
	public void changeAvailability(int roomId) throws HBMSException {
		
		Rooms room=entityManager.find(Rooms.class, roomId);
		room.setAvailability("no");
		entityManager.persist(room);
		
	}

}
