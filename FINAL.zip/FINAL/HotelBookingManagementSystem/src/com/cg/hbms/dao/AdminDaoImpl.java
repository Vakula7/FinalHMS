package com.cg.hbms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.hbms.entities.Hotels;
import com.cg.hbms.entities.Rooms;
import com.cg.hbms.exception.HBMSException;

@Repository
@Transactional
public class AdminDaoImpl implements IAdminDao{

	@PersistenceContext
	EntityManager em;
	
	/****************************************************************************************************************************
	 - Method Name      : persistHotel
	 - Input Parameters : hotel
	 - Return type      : int
	 - Author           : Sumanth
	 - Creation Date    : 19-02-2018
	 - Description      : Inserting the Hotel information entered by admin   into  the database.
	  ****************************************************************************************************************************/ 
	
	@Override
	public int persistHotel(Hotels hotel) throws HBMSException {
		int id = 0;
		
		em.persist(hotel);
		em.flush();
		
		id=hotel.getHotelId();
		return id;
	}

	/****************************************************************************************************************************
	 - Method Name      : showHotelList
	 - Input Parameters : NIL
	 - Return type      : List<Hotels>
	 - Author           : Sumanth
	 - Creation Date    : 19-02-2018
	 - Description      : Retrieves the list of all Hotels 
	  ****************************************************************************************************************************/ 
	
	@Override
	public List<Hotels> showHotelList() throws HBMSException {
		
		List<Hotels> hotelList=null;
		
		TypedQuery<Hotels> query=em.createQuery("SELECT hotels FROM Hotels hotels", Hotels.class);
		
		hotelList=query.getResultList();
		
		return hotelList;
	}
	
	
	/****************************************************************************************************************************
	 - Method Name      : updateHotel
	 - Input Parameters : hotel
	 - Return type      : List<Hotels>
	 - Author           : Sumanth
	 - Creation Date    : 19-02-2018
	 - Description      : Retrieves the list of all Hotels 
	  ****************************************************************************************************************************/ 

	@Override
	public Hotels updateHotel(Hotels hotel) throws HBMSException {
	
		
		em.merge(hotel);
		Hotels hotel1=em.find(Hotels.class, hotel.getHotelId());
		return hotel1;
	}

	@Override
	public int deleteHotel(int hotelId) throws HBMSException {
	
		int id=0;
		Hotels hotel=null;
		hotel=em.find(Hotels.class, hotelId);
		id=hotel.getHotelId();
		if(hotel!=null){
			em.remove(hotel);
		}
		
		return id;
	}

	@Override
	public Hotels getHotelById(int hotelId) throws HBMSException {
		
		Hotels hotel=null;
		hotel=em.find(Hotels.class, hotelId);
		return hotel;
	}

	@Override
	public List<Rooms> showRoomsList(int hotelId) throws HBMSException {
		
		List<Rooms> roomList=null;
		TypedQuery<Rooms> query=em.createQuery("SELECT rooms FROM Rooms rooms WHERE rooms.hotelId=?", Rooms.class);
		query.setParameter(1, hotelId);
		roomList=query.getResultList();
		return roomList;
	}

	
	@Override
	public int persistRoom(Rooms room) throws HBMSException {
		
	int id = 0;
		
		em.persist(room);
		em.flush();
		
		id=room.getRoomId();
		return id;
		
	}

	
	
}
