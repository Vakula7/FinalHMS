package com.cg.hbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="hotel_details")
public class Hotels {
	
	@Id
	@SequenceGenerator(name="sequence",sequenceName="seq_hotel_id",  allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sequence")
	private int hotelId;
	
	
	@Column(name="city")
	@NotEmpty(message="Please fill out this field!")
	@Pattern(regexp="[a-zA-Z\\s]+",message="Please enter valid city")
	private String city;
	
	@Column(name="hotelName")
	@NotEmpty(message="Please fill out this field!")
	@Pattern(regexp="[a-zA-Z][a-zA-Z0-9\\s\\-]{2,20}",message="Name must start with alphabet and can contain hyphen should be in range 3 to 20!!")
	private String hotelName;
	
	@Column(name="hotelAddress")
	@NotEmpty(message="Please fill out this field!")
	@Pattern(regexp="[a-zA-Z][a-zA-Z0-9\\s\\,\\.\\-\\/]{2,}",message="Please enter valid address")
	private String hotelAddress;
	
	
	@Column(name="hotelDescription")
	@NotEmpty(message="Please fill out this field")
	@Pattern(regexp="[a-zA-Z][a-zA-Z0-9\\s\\,\\.\\-\\!]+",message="Please enter valid Description")
	private String hotelDescription;
	
	@Column(name="avgRatePerNight")
/*	@NotEmpty(message="Average Rate should not be Empty")*/
	@Min(value=1000,message="Please enter valid amount and should be greater than 1000")
	private double avgRatePerNight;
	
	
	@Column(name="phoneNumber")
	@NotEmpty(message="Please fill out this field")
	@Pattern(regexp="[9|8|7][0-9]{9}",message="Please enter a valid Phone Number")
	private String phoneNumber;
	
	
	@Column(name="hotelRating")
	@NotEmpty(message="Please fill out this field")
	//@Pattern(regexp="[*]{1,5}",message="Enter only *(1 to 5)")
	private String hotelRating;
	
	@Column(name="hotelEmail")
	@NotEmpty(message="Please fill out this field")
	@Pattern(regexp="[a-z]{1}[a-z0-9]+@[a-z]+.[a-z]+",message="Please enter a valid email")
	private String hotelEmail;

	
	
	public Hotels() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Hotels(int hotelId, String city, String hotelName,
			String hotelAddress, String hotelDescription,
			double avgRatePerNight, String phoneNumber, String hotelRating,
			String hotelEmail) {
		super();
		this.hotelId = hotelId;
		this.city = city;
		this.hotelName = hotelName;
		this.hotelAddress = hotelAddress;
		this.hotelDescription = hotelDescription;
		this.avgRatePerNight = avgRatePerNight;
		this.phoneNumber = phoneNumber;
		this.hotelRating = hotelRating;
		this.hotelEmail = hotelEmail;
	}



	public int getHotelId() {
		return hotelId;
	}



	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getHotelName() {
		return hotelName;
	}



	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}



	public String getHotelAddress() {
		return hotelAddress;
	}



	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}



	public String getHotelDescription() {
		return hotelDescription;
	}



	public void setHotelDescription(String hotelDescription) {
		this.hotelDescription = hotelDescription;
	}



	public double getAvgRatePerNight() {
		return avgRatePerNight;
	}



	public void setAvgRatePerNight(double avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}



	public String getPhoneNumber() {
		return phoneNumber;
	}



	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}



	public String getHotelRating() {
		return hotelRating;
	}



	public void setHotelRating(String hotelRating) {
		this.hotelRating = hotelRating;
	}



	public String getHotelEmail() {
		return hotelEmail;
	}



	public void setHotelEmail(String hotelEmail) {
		this.hotelEmail = hotelEmail;
	}
	
	
	
	

}
