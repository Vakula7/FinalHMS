package com.cg.hbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="users")
public class Users {
	

	@Id
	@Column(name="userName")
	@NotEmpty(message="Mandatory")
	@Pattern(regexp="[a-zA-z][a-zA-Z0-9]{1,6}",message="UserName can contain upto 8 characters and should start with alphabets")
	private String userName;
	
	
	
	@Column(name="password")
	@Size(min=5,max=10,message="Password should be minimum of 5 characters and maximum of 10 characters")
	@NotEmpty(message="Mandatory")
	private String password;
	
	
	@Transient
	@Column(name="confirmPassword")
	@NotEmpty(message="Mandatory")
	@Size(min=5,max=10,message="Password should be minimum of 5 characters and maximum of 10 characters")
	
	private String confirmPassword;
	
	public String getConfirmPassword() {
		return confirmPassword;
	}


	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}


	@Column(name="role")
	private String role;
	
	@Column(name="fullName")
	@NotEmpty(message="Mandatory")
	@Pattern(regexp="[a-zA-Z\\s]{4,25}", message="Name should contain only alphabets with a minimum of 4 and maximum of 25 characters")
	private String fullName;
	
	@Column(name="phoneNumber")
	@NotEmpty(message="Mandatory")
	@Pattern(regexp="[9|8|7][0-9]{9}",message="Enter a valid Phone Number")
	private String phoneNumber;
	
	@Column(name="address")
	@NotEmpty(message="Mandatory")
	@Pattern(regexp="[a-zA-Z0-9\\s,.]{1,}",message="Address should start only with alphabets")
	private String address;
	
	@Column(name="email")
	@NotEmpty(message="Mandatory")
	@Pattern(regexp="[a-z]{1}[a-z0-9]+@[a-z]+.[a-z]+",message="Enter a valid email")
	private String email;
	
	
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Users(String userName, String password, String role,
			String fullName, String phoneNumber, String address, String email) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
		this.fullName = fullName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.email = email;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
