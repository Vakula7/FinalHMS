package com.cg.hbms.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name="booking_details")
public class Bookings {
	
	@Id
	@Column(name="bookingId")
	@SequenceGenerator(name="sequence_book", sequenceName="booking_id_seq", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sequence_book")
	private int bookingId;
	
	@Column(name="roomId")
	private int roomId;
	
	@Column(name="hotelId")
	private int hotelId;
	
	@Column(name="userName")
	private String userName;
	
	@Column(name="bookedFrom")
	@DateTimeFormat(pattern="dd-MM-yyyy")
	@NotNull(message="required")
	private Date bookedFrom;
	
	@Column(name="bookedTo")
	@DateTimeFormat(pattern="dd-MM-yyyy")
	@NotNull(message="required")
	private Date bookedTo;
	
	@Column(name="numberOfAdults")
	@NotNull(message="required")
	private int numberOfAdults;
	
	@Column(name="numberOfChildren")
	@NotNull(message="required")
	private int numberOfChildren;
	
	@Column(name="amount")
	private double amount;

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getBookedFrom() {
		return bookedFrom;
	}

	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}

	public Date getBookedTo() {
		return bookedTo;
	}

	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}

	public int getNumberOfAdults() {
		return numberOfAdults;
	}

	public void setNumberOfAdults(int numberOfAdults) {
		this.numberOfAdults = numberOfAdults;
	}

	public int getNumberOfChildren() {
		return numberOfChildren;
	}

	public void setNumberOfChildren(int numberOfChildren) {
		this.numberOfChildren = numberOfChildren;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public Bookings(int bookingId, String userName, Date bookedFrom,
			Date bookedTo, int numberOfAdults, int numberOfChildren,
			double amount) {
		super();
		this.bookingId = bookingId;
		this.userName = userName;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.numberOfAdults = numberOfAdults;
		this.numberOfChildren = numberOfChildren;
		this.amount = amount;
	}

	public Bookings() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
