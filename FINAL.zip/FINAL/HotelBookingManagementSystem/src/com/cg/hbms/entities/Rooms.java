package com.cg.hbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="room_details")
public class Rooms {
	
	@Id
	@Column(name="roomId")
/*	@SequenceGenerator(name="seq1",sequenceName="room_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq1")*/
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int roomId;
	
	@Column(name="hotelId")
	private int hotelId;
	
	@Column(name="roomNo")
	@NotEmpty(message="Mandatory")
	@Pattern(regexp="[a-zA-Z0-9\\s]+",message="Room No should not contain any special characters")
	private String roomNo;
	
	@Column(name="roomType")
	@NotEmpty(message="Mandatory")
	private String roomType;
	
	
	@Column(name="ratePerNight")
	@Min(value=500,message="Amount should be greater than 500")
	private double ratePerNight;
	
	@Column(name="availability")
	@NotEmpty(message="Mandatory")
	private String availability;

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public double getRatePerNight() {
		return ratePerNight;
	}

	public void setRatePerNight(double ratePerNight) {
		this.ratePerNight = ratePerNight;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public Rooms() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Rooms(int roomId, int hotelId, String roomNo, String roomType,
			double ratePerNight, String availability) {
		super();
		this.roomId = roomId;
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.ratePerNight = ratePerNight;
		this.availability = availability;
	}
	
	
	
	

}
