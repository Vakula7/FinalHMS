package com.cg.hbms.controller;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hbms.entities.Bookings;
import com.cg.hbms.entities.Hotels;
import com.cg.hbms.entities.Rooms;
import com.cg.hbms.entities.Users;
import com.cg.hbms.exception.HBMSException;
import com.cg.hbms.service.IAdminService;
import com.cg.hbms.service.UserService;

@Controller
@RequestMapping("/*.obj")
@SessionAttributes("session_user")
public class HotelLoginController {

	Users globalUser;

	public Users getGlobalUser() {
		return globalUser;
	}

	public void setGlobalUser(Users globalUser) {
		this.globalUser = globalUser;
	}

	@Autowired
	UserService service;

	public UserService getService() {
		return service;
	}

	public void setService(UserService service) {
		this.service = service;
	}

	@RequestMapping("/showHomePage")
	public ModelAndView showHomepage() {
		Users user = new Users();
		return new ModelAndView("login", "user", user);

	}

	@Autowired
	IAdminService admniService;

	public IAdminService getAdmniService() {
		return admniService;
	}

	public void setAdmniService(IAdminService admniService) {
		this.admniService = admniService;
	}

	@RequestMapping("/processLoginForm")
	public ModelAndView processLogin(@ModelAttribute("user") Users user) {

		ModelAndView mv = null;

		try {

			System.out.println("Inside try !!!!!");
			user = service.validateUser(user);
			setGlobalUser(user);
			System.out.println(user.getFullName());
			if (user.getRole().equalsIgnoreCase("admin")) {
				mv = new ModelAndView("AdminPage");
				mv.addObject("session_user", user);
				List<Hotels> hotelList = null;
				hotelList = admniService.showHotelList();
				mv.addObject("hotelList", hotelList);
			} else if (user.getRole().equalsIgnoreCase("customer")) {
				mv = new ModelAndView("HotelList");
				mv.addObject("session_user", user);
				List<Hotels> hotelList = null;
				hotelList = admniService.showHotelList();
				mv.addObject("list", hotelList);

			} else {
				mv = new ModelAndView("login", "message",
						"Invalid username or password");
				mv.addObject("check", "true");
			}
		} catch (HBMSException e) {
			mv = new ModelAndView("login", "user", user);
			mv.addObject("message", "Invalid username or password");
			mv.addObject("check", "true");
		}

		return mv;

	}

	@RequestMapping("/customerHome")
	public ModelAndView showCustomerHome() {

		ModelAndView mv;
		mv = new ModelAndView("HotelList");

		mv.addObject("session_user", getGlobalUser());
		List<Hotels> hotelList = null;
		try {
			hotelList = admniService.showHotelList();
		} catch (HBMSException e) {
			mv = new ModelAndView("HotelList");
			
		}

		mv.addObject("list", hotelList);
		return mv;

	}

	@RequestMapping("/AdminHome")
	public ModelAndView showAdminHome() {
		ModelAndView mv = null;
		mv = new ModelAndView("AdminPage");
		mv.addObject("session_user", getGlobalUser());
		List<Hotels> hotelList = null;
		try {
			hotelList = admniService.showHotelList();
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("hotelList", hotelList);
		return mv;

	}

	/*
	 * @RequestMapping("/signUp") public ModelAndView showSignUp(){
	 * 
	 * Users userData=new Users(); return new
	 * ModelAndView("signUp","userSignUp",userData);
	 * 
	 * 
	 * }
	 */

	@RequestMapping("/registerUser")
	public ModelAndView registerUser(
			@ModelAttribute("user") @Valid Users userData, BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {

			if (userData.getConfirmPassword().equals(userData.getPassword())) {
				try {
					service.registerUser(userData);
					System.out.println("abcd");
					mv = new ModelAndView("SignUpStatus", "message",
							"Registered Successfully!!");
				} catch (HBMSException e) {
					mv = new ModelAndView("SignUpStatus", "message",
							e.getMessage());
				}
			} else {

				mv = new ModelAndView("login", "message",
						"passwords do not match");
				mv.addObject("check", "true");
			}
		} else {
			mv = new ModelAndView("login", "user", userData);
		}

		return mv;
	}

	@RequestMapping("/adminHomePage")
	public ModelAndView showAdminHomePage() {
		ModelAndView mv = null;
		List<Hotels> hotelList = null;
		try {
			hotelList = admniService.showHotelList();
			mv = new ModelAndView("AdminPage", "hotelList", hotelList);
		} catch (HBMSException e) {
			mv = new ModelAndView("AdminPage", "message",
					"OOps!! Exception occured");
			mv.addObject("check", "true");
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping("/searchByCity")
	public ModelAndView searchHotelByCity(@RequestParam("city") String place) {

		ModelAndView mv = null;

		try {
			List<Hotels> hotelList = null;
			hotelList = service.getHotelByPlace(place);
			mv = new ModelAndView("HotelList");
			mv.addObject("list", hotelList);
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping(value = "/bookingForm", method = RequestMethod.POST)
	public ModelAndView showBookingList(
			@ModelAttribute("session_user") Users user,
			@RequestParam("hotelId") int hotelId) {

		ModelAndView mv = null;

		Hotels hotel = null;
		List<Rooms> roomList = null;
		try {
			hotel = service.getHotelByID(hotelId);
			roomList = service.getRoomDetailsById(hotelId);
			mv = new ModelAndView("Booking", "hotel", hotel);
			mv.addObject("roomData", roomList);
			mv.addObject("session_user", user);
			if (roomList.isEmpty()) {
				mv = new ModelAndView("Booking", "msg",
						"Sorry!!! No Rooms Available.Thank you "
								+ user.getFullName());
				mv.addObject("hotel", hotel);
				mv.addObject("roomData", null);
				mv.addObject("session_user", user);
			}
		} catch (HBMSException e) {

			mv = new ModelAndView("HotelList", "msg",
					"OOps!! Something went wrong");

		}

		return mv;

	}

	@RequestMapping(value = "/showBookingForm", method = RequestMethod.POST)
	public ModelAndView showBookingForm(
			@ModelAttribute("session_user") Users user,
			@RequestParam("roomId") int roomId) {

		ModelAndView mv = null;
		Bookings book = new Bookings();
		try {
			book.setRoomId(roomId);
			book.setUserName(user.getUserName());
			double amount = 0;
			amount = service.getFareByRoomId(roomId);
			book.setAmount(amount);
			mv = new ModelAndView("BookingForm", "bookingData", book);
		} catch (HBMSException e) {
			mv = new ModelAndView("BookingForm", "bookingData", book);
		}
		return mv;
	}

	/*
	 * @RequestMapping(value="/ProcessRoomBookingForm",method=RequestMethod.POST)
	 * public ModelAndView persistBookingDetails(@ModelAttribute("bookingData")
	 * Bookings bookingDetails){
	 * 
	 * ModelAndView mv=null;
	 * 
	 * Date checkIn=bookingDetails.getBookedFrom();
	 * bookingDetails.setBookedFrom(checkIn); Date
	 * checkOut=bookingDetails.getBookedTo();
	 * bookingDetails.setBookedTo(checkOut);
	 * 
	 * if(!checkOut.after(checkIn)){
	 * 
	 * mv=new ModelAndView("BookingForm","bookingData",bookingDetails);
	 * mv.addObject("dateErr", "Check in date should be before checkout date");
	 * }
	 * 
	 * Date currentDate=new Date();
	 * 
	 * if(!checkIn.after(currentDate)){
	 * 
	 * mv=new ModelAndView("BookingForm","bookingData",bookingDetails);
	 * mv.addObject("dateErr1", "Check in date should be before checkout date");
	 * }
	 * 
	 * 
	 * if(bookingDetails.getNumberOfAdults()>4||bookingDetails.getNumberOfAdults(
	 * )<1){ mv=new ModelAndView("BookingForm","bookingData",bookingDetails);
	 * mv.addObject("NoOfAdultErr", "Number of adults should be 1 to 4");
	 * 
	 * }
	 * 
	 * if(bookingDetails.getNumberOfChildren()>4||bookingDetails.getNumberOfChildren
	 * ()<1){ mv=new ModelAndView("BookingForm","bookingData",bookingDetails);
	 * mv.addObject("NoOfChildErr", "Number of children should be 1 to 4");
	 * 
	 * }
	 * 
	 * long differenceInDate=checkOut.getTime()-checkIn.getTime(); long
	 * numberOfDays=TimeUnit.DAYS.convert(differenceInDate,
	 * TimeUnit.MILLISECONDS); try { double
	 * fare=service.getFareByRoomId(bookingDetails.getRoomId()); int
	 * total=bookingDetails
	 * .getNumberOfAdults()+bookingDetails.getNumberOfChildren(); double
	 * amountForSingleDay=total*fare; double
	 * amount=amountForSingleDay*numberOfDays; bookingDetails.setAmount(amount);
	 * 
	 * int bookingId=service.persistBookingDetails(bookingDetails);
	 * 
	 * int roomId=bookingDetails.getRoomId();
	 * 
	 * service.changeAvailability(roomId);
	 * 
	 * mv=new ModelAndView("BookingSuccess","bookingId",bookingId);
	 * mv.addObject("message",
	 * "Your Room has been booked!!. Kindly pay "+amount+"on check out");
	 * 
	 * } catch (HBMSException e) {
	 * 
	 * mv=new
	 * ModelAndView("BookingSuccess","message","Some error occured! try Later");
	 * }
	 * 
	 * return mv; }
	 */

	@RequestMapping("/ProcessRoomBookingForm")
	public String processBookingForm(
			@ModelAttribute("bookingData") @Valid Bookings booking,
			BindingResult bindingResult, Model model) {

		if (bindingResult.hasErrors()) {
			return "BookingForm";
		}

		try {
			Date checkOutDate, checkInDate;
			checkInDate = booking.getBookedFrom();
			booking.setBookedFrom(checkInDate);
			checkOutDate = booking.getBookedTo();

			booking.setBookedTo(checkOutDate);

			if (!checkOutDate.after(checkInDate)) {

				model.addAttribute("bookingData", booking);
				model.addAttribute("dateErr",
						"*Check-In Date Should be before Check-Out Date");
				return "BookingForm";
			}

			Date d = new Date();
			if (!checkInDate.after(d)) {
				model.addAttribute("bookingData", booking);
				model.addAttribute("dateErr1",
						"*Check-In Date Should be after Today");
				return "BookingForm";
			}

			if (booking.getNumberOfAdults() > 4
					|| booking.getNumberOfAdults() < 1) {
				model.addAttribute("bookingData", booking);
				model.addAttribute("NoOfAdultErr",
						"*No Of Adults Should be 1 to 4");
				return "BookingForm";
			}

			if (booking.getNumberOfChildren() > 4
					|| booking.getNumberOfChildren() < 1) {
				model.addAttribute("bookingData", booking);
				model.addAttribute("NoOfChildErr",
						"*No Of Children Should be Less Than 5");
				return "BookingForm";
			}

			long difference = checkOutDate.getTime() - checkInDate.getTime();

			System.out.println("difference=" + difference);

			long days = TimeUnit.DAYS
					.convert(difference, TimeUnit.MILLISECONDS);
			System.out.println("dayes =" + days);
			/*
			 * double
			 * totalAmount=booking.getAmount()*Double.parseDouble(days+"");
			 * 
			 * booking.setAmount(totalAmount);
			 * System.out.println("Amount ="+totalAmount);
			 */
			double fare = service.getFareByRoomId(booking.getRoomId());
			int total = booking.getNumberOfAdults()
					+ booking.getNumberOfChildren();
			double amountForSingleDay = total * fare;
			double amount = amountForSingleDay * days;
			booking.setAmount(amount);
			int bookingId = service.persistBookingDetails(booking);

			// To Change room availability status

			service.changeAvailability(booking.getRoomId());

			model.addAttribute("totalAmount", amount);
			model.addAttribute("bookingId", bookingId);
			model.addAttribute("booking", booking);
			System.out.println(booking);
			return "SuccessPage";

		} catch (HBMSException e) {

			model.addAttribute("errMsg",
					"Something went wrong while booking room" + e.getMessage());
			return "ErrorPage";
		} catch (Exception e) {

			model.addAttribute("errMsg",
					"Something went wrong while booking room" + e.getMessage());
			return "ErrorPage";
		}
	}
}
